import matplotlib
import matplotlib.pyplot as plt
import os
RUTA_BASE = os.path.dirname(os.path.abspath(__file__))
RUTA_DATOS = os.path.join(RUTA_BASE, "data")
RUTA_SALIDAS = os.path.join(RUTA_BASE, "outputs")
EXTENSIONES_VALIDAS = (".txt", ".csv")

TOP_PALABRAS_RESUMEN = 5       
TOP_PALABRAS_GRAFICO = 10      
ANCHO_INTERVALO = 50           
MAX_INTERVALOS = 12            
FILAS_INICIO = 10              
FILAS_FINAL = 5                
ANCHO_CELDA = 14               
MAX_CATEGORIAS_PASTEL = 7      
MAX_CATEGORIAS_DISPERSION = 3  
MAX_ETIQUETAS_EJE_X = 10       

VALORES_NULOS = ("", "na", "n/a", "nan", "null", "none", "-", "--", "?",
                 "sin dato", "nd", "s/d")

NIVELES_LOG = ("emerg", "alert", "crit", "critical", "fatal", "error",
               "warn", "warning", "notice", "info", "debug", "trace")

PALABRAS_ERROR = ("error", "fail", "fatal", "denied", "exception", "timeout",
                  "warn")

MESES = ("Jan", "Feb", "Mar", "Apr", "May", "Jun",
         "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

SIGNOS_PUNTUACION = ".,;:¡!¿?\"'()[]{}<>«»-—_*/\\|#$%&=+~^`´¨…“”‘’0123456789º"


PALABRAS_VACIAS = {
    "el", "la", "los", "las", "un", "una", "unos", "unas", "lo", "al", "del",
    "a", "á", "ante", "bajo", "con", "contra", "de", "desde", "en", "entre",
    "hacia", "hasta", "para", "por", "según", "sin", "so", "sobre", "tras",
    "durante", "mediante",
    "y", "e", "é", "o", "ó", "u", "ni", "que", "pero", "mas", "más", "sino",
    "aunque", "porque", "pues", "como", "cómo", "cuando", "si", "mientras",
    "donde", "dónde", "ya", "así", "luego", "entonces", "también", "tampoco",
    "qué", "cual", "cuál", "cuales", "cuyo", "cuya", "quien", "quién",
    "quienes", "no", "sí", "muy", "tan", "tanto", "tanta", "tantos", "tantas",
    "aquí", "allí", "ahí", "acá", "allá", "solo", "sólo", "aun", "aún",
    "todo", "toda", "todos", "todas", "otro", "otra", "otros", "otras",
    "yo", "tú", "él", "ella", "ello", "ellos", "ellas", "nosotros", "vosotros",
    "me", "te", "se", "nos", "os", "le", "les", "mí", "ti", "conmigo",
    "contigo", "consigo", "mi", "mis", "tu", "tus", "su", "sus", "nuestro",
    "nuestra", "nuestros", "nuestras", "vuestro", "vuestra", "vuestros",
    "vuestras", "este", "esta", "esto", "estos", "estas", "ese", "esa", "eso",
    "esos", "esas", "aquel", "aquella", "aquello", "aquellos", "aquellas",
    "es", "son", "era", "eran", "fue", "fueron", "ser", "sea", "sido", "soy",
    "eres", "fuese", "fuera", "ha", "han", "he", "has", "había", "habían",
    "hay", "haber", "habiendo", "hubo", "hubiese", "hubiera", "está", "están",
    "estaba", "estar", "estoy",
    "tiene", "tienen", "tenía", "tenían", "tener", "tengo", "tuvo",
    "puede", "pueden", "podía", "podían", "poder", "pudo",
    "hace", "hacen", "hacía", "hacer", "hizo",
    "uno", "dos", "tres", "cada", "casi", "mismo", "misma", "mismos",
    "mismas", "tal", "tales", "algo", "alguno", "alguna", "algunos",
    "algunas", "ningún", "ninguno", "ninguna", "mucho", "mucha", "muchos",
    "muchas", "poco", "poca", "pocos", "pocas", "siempre", "nunca", "ahora",
    "después", "antes", "menos", "vez", "veces",
    "the", "an", "and", "or", "of", "to", "in", "on", "for", "with", "at",
    "by", "from", "as", "into", "about", "than", "then", "but", "if", "not",
    "is", "are", "was", "were", "be", "been", "it", "its", "this", "that",
    "these", "those", "i", "you", "she", "we", "they", "my", "your", "his",
    "her", "our", "their", "him", "them", "do", "does", "did", "have", "had",
    "will", "would", "can", "there",
}

COLORES_SERIES = ("#2a78d6", "#eb6834", "#1baf7a", "#eda100",
                  "#e87ba4", "#008300", "#6250d6", "#e34948")
COLOR_OTROS = "#c3c2b7"
COLOR_FONDO = "#fcfcfb"
COLOR_TEXTO = "#0b0b0b"
COLOR_TEXTO_SECUNDARIO = "#52514e"
COLOR_APAGADO = "#898781"
COLOR_CUADRICULA = "#e1e0d9"
COLOR_EJE = "#c3c2b7"

def imprimir_titulo(texto):
    linea = "=" * (len(texto) + 4)
    print("\n" + linea)
    print("  " + texto)
    print(linea)

def imprimir_subtitulo(texto):
    print("\n" + texto)
    print("-" * len(texto))

def pausar():
    input("\nPresione Enter para continuar...")

def pedir_texto(mensaje):
    return input(mensaje).strip()

def pedir_opcion(mensaje, minimo, maximo):
    while True:
        respuesta = input(mensaje).strip()
        if respuesta.isdigit():
            numero = int(respuesta)
            if minimo <= numero <= maximo:
                return numero
        print("  [!] Opción inválida. Escriba un número entre "
              + str(minimo) + " y " + str(maximo) + ".")

def pedir_entero_opcional(mensaje, minimo, maximo):
    while True:
        respuesta = input(mensaje).strip()
        if respuesta == "":
            return None
        if respuesta.isdigit():
            numero = int(respuesta)
            if minimo <= numero <= maximo:
                return numero
        print("  [!] Escriba un número entre " + str(minimo) + " y "
              + str(maximo) + ", o presione Enter para omitir.")

def pedir_si_no(mensaje):
    while True:
        respuesta = input(mensaje + " (s/n): ").strip().lower()
        if respuesta in ("s", "si", "sí"):
            return True
        if respuesta in ("n", "no"):
            return False
        print("  [!] Responda 's' o 'n'.")

def sumar_uno(diccionario, clave):
    if clave in diccionario:
        diccionario[clave] = diccionario[clave] + 1
    else:
        diccionario[clave] = 1

def top_n(conteos, n):
    resultado = []
    elegidos = set()
    vueltas = min(n, len(conteos))
    for _ in range(vueltas):
        mejor_clave = None
        mejor_conteo = -1
        for clave in conteos:
            if clave not in elegidos and conteos[clave] > mejor_conteo:
                mejor_clave = clave
                mejor_conteo = conteos[clave]
        elegidos.add(mejor_clave)
        resultado.append((mejor_clave, mejor_conteo))
    return resultado

def formatear_numero(valor, decimales=2):
    if valor == int(valor) and abs(valor) < 1e15:
        return "{:,}".format(int(valor))
    return "{:,.{}f}".format(valor, decimales)

def porcentaje(parte, total):
    if total == 0:
        return 0.0
    return parte * 100.0 / total

def nombre_seguro(texto):
    resultado = ""
    for caracter in texto.lower():
        if caracter.isalnum():
            resultado = resultado + caracter
        elif resultado != "" and resultado[-1] != "_":
            resultado = resultado + "_"
    resultado = resultado.strip("_")
    if resultado == "":
        resultado = "archivo"
    return resultado[:60]

def recortar_texto(texto, ancho):
    if len(texto) <= ancho:
        return texto
    return texto[:ancho - 2] + ".."


def ruta_relativa(ruta):
    return os.path.relpath(ruta, RUTA_BASE)

def listar_archivos(directorio, extensiones):
    if not os.path.exists(directorio):
        raise FileNotFoundError("La ruta '" + directorio + "' no existe.")
    if not os.path.isdir(directorio):
        raise NotADirectoryError("'" + directorio + "' no es una carpeta.")

    archivos = []
    for nombre in sorted(os.listdir(directorio)):
        ruta = os.path.join(directorio, nombre)
        extension = os.path.splitext(nombre)[1].lower()
        if os.path.isfile(ruta) and extension in extensiones:
            archivo = {
                "nombre": nombre,
                "ruta": ruta,
                "extension": extension,
                "tamano_kb": os.path.getsize(ruta) / 1024,
            }
            archivos.append(archivo)
    return archivos

def mostrar_lista_archivos(archivos):
    print("\n  N°   Tipo   Tamaño (KB)   Nombre")
    print("  ---  -----  ------------  ----------------------------------------")
    numero = 1
    for archivo in archivos:
        print("  {:<3}  {:<5}  {:>12,.1f}  {}".format(
            numero, archivo["extension"], archivo["tamano_kb"], archivo["nombre"]))
        numero = numero + 1

def explorar_directorio(directorio_actual):
    imprimir_titulo("EXPLORAR DIRECTORIO")
    ruta = pedir_texto("Ruta a explorar [Enter = " + directorio_actual + "]: ")
    if ruta == "":
        ruta = directorio_actual
    ruta = os.path.abspath(os.path.expanduser(ruta))

    try:
        archivos = listar_archivos(ruta, EXTENSIONES_VALIDAS)
    except (FileNotFoundError, NotADirectoryError) as error:
        print("  [!] " + str(error))
        return directorio_actual
    except PermissionError:
        print("  [!] No tiene permisos para leer la carpeta '" + ruta + "'.")
        return directorio_actual

    if len(archivos) == 0:
        print("\n  La carpeta existe, pero no contiene archivos .txt ni .csv.")
    else:
        total_txt = 0
        total_csv = 0
        for archivo in archivos:
            if archivo["extension"] == ".txt":
                total_txt = total_txt + 1
            else:
                total_csv = total_csv + 1
        print("\n  Carpeta: " + ruta)
        mostrar_lista_archivos(archivos)
        print("\n  Total: " + str(total_txt) + " archivo(s) .txt y "
              + str(total_csv) + " archivo(s) .csv")
    print("\n  Esta carpeta queda seleccionada para las opciones 2 y 3.")
    return ruta


def seleccionar_archivo(directorio, extension):
    archivos = []
    try:
        archivos = listar_archivos(directorio, (extension,))
    except (FileNotFoundError, NotADirectoryError, PermissionError):
        print("  [!] No se pudo leer la carpeta '" + directorio + "'.")

    if len(archivos) > 0:
        print("\nArchivos " + extension + " en " + directorio + ":")
        mostrar_lista_archivos(archivos)
    else:
        print("\n  No hay archivos " + extension + " en la carpeta actual.")

    print("\n  Escriba el número del archivo, una ruta completa, o 0 para volver.")
    while True:
        respuesta = pedir_texto("Archivo: ")
        if respuesta == "0":
            return None
        if respuesta.isdigit() and 1 <= int(respuesta) <= len(archivos):
            return archivos[int(respuesta) - 1]["ruta"]
        if respuesta == "":
            print("  [!] Escriba una opción.")
            continue
        ruta = os.path.abspath(os.path.expanduser(respuesta))
        if not os.path.isfile(ruta):
            print("  [!] El archivo '" + respuesta + "' no existe. Intente de nuevo.")
        elif os.path.splitext(ruta)[1].lower() != extension:
            print("  [!] El archivo debe tener extensión " + extension + ".")
        else:
            return ruta

def detectar_codificacion(ruta):
    try:
        with open(ruta, "r", encoding="utf-8-sig") as archivo:
            archivo.read()
        return "utf-8-sig"
    except UnicodeDecodeError:
        return "latin-1"

def leer_contenido(ruta):
    codificacion = detectar_codificacion(ruta)
    with open(ruta, "r", encoding=codificacion) as archivo:
        contenido = archivo.read()
    return contenido, codificacion

def quitar_licencia_gutenberg(lineas):
    inicio = -1
    fin = len(lineas)
    for i in range(len(lineas)):
        if inicio == -1 and lineas[i].startswith("*** START OF"):
            inicio = i
        elif inicio != -1 and lineas[i].startswith("*** END OF"):
            fin = i
            break
    if inicio == -1:
        return lineas, False
    return lineas[inicio + 1:fin], True

def cargar_texto(ruta):
    contenido, codificacion = leer_contenido(ruta)
    lineas, licencia_omitida = quitar_licencia_gutenberg(contenido.splitlines())
    datos = {
        "nombre": os.path.basename(ruta),
        "ruta": ruta,
        "lineas": lineas,
        "codificacion": codificacion,
        "licencia_omitida": licencia_omitida,
        "conteo_palabras": contar_palabras(lineas),
    }
    return datos

def limpiar_palabra(token):
    palabra = token.lower().strip(SIGNOS_PUNTUACION)
    for caracter in palabra:
        if caracter.isalpha():
            return palabra
    return ""

def separar_tokens(linea):
    linea = linea.replace("--", " ").replace("—", " ")
    return linea.split()

def contar_palabras(lineas):
    conteo = {}
    for linea in lineas:
        for token in separar_tokens(linea):
            palabra = limpiar_palabra(token)
            if palabra != "" and palabra not in PALABRAS_VACIAS:
                sumar_uno(conteo, palabra)
    return conteo

def calcular_resumen(lineas):
    total_palabras = 0
    caracteres_con_espacios = 0
    caracteres_sin_espacios = 0
    lineas_vacias = 0
    for linea in lineas:
        tokens = linea.split()
        if len(tokens) == 0:
            lineas_vacias = lineas_vacias + 1
        total_palabras = total_palabras + len(tokens)
        caracteres_con_espacios = caracteres_con_espacios + len(linea)
        caracteres_sin_espacios = caracteres_sin_espacios + len("".join(tokens))

    lineas_con_texto = len(lineas) - lineas_vacias
    promedio = 0.0
    if lineas_con_texto > 0:
        promedio = caracteres_con_espacios / lineas_con_texto

    resumen = {
        "total_lineas": len(lineas),
        "lineas_vacias": lineas_vacias,
        "total_palabras": total_palabras,
        "caracteres_con_espacios": caracteres_con_espacios,
        "caracteres_sin_espacios": caracteres_sin_espacios,
        "promedio_caracteres_linea": promedio,
    }
    return resumen

def extraer_fecha_log(linea):
    if (len(linea) >= 10 and linea[4] == "-" and linea[7] == "-"
            and linea[:4].isdigit() and linea[5:7].isdigit()
            and linea[8:10].isdigit()):
        return linea[:10]

    inicio = linea.find("[")
    if inicio == -1:
        return ""
    fin = linea.find("]", inicio)
    if fin == -1:
        return ""
    contenido = linea[inicio + 1:fin]

    if contenido.count("/") == 2 and ":" in contenido:
        return contenido.split(":")[0]

    partes = contenido.split()
    if len(partes) == 5 and partes[1] in MESES and ":" in partes[3]:
        return partes[2] + "/" + partes[1] + "/" + partes[4]
    return ""

def extraer_codigo_http(linea):
    partes = linea.split('"')
    if len(partes) < 3:
        return ""
    tokens = partes[2].split()
    if len(tokens) > 0 and len(tokens[0]) == 3 and tokens[0].isdigit():
        return tokens[0]
    return ""

def extraer_nivel_log(linea):
    tokens = linea.split()
    limite = min(6, len(tokens))
    for i in range(limite):
        token = tokens[i].strip("[]:()").lower()
        if token in NIVELES_LOG:
            return token.upper()
    return ""

def es_archivo_log(lineas):
    revisadas = 0
    con_fecha = 0
    for linea in lineas:
        if linea.strip() == "":
            continue
        revisadas = revisadas + 1
        if extraer_fecha_log(linea) != "":
            con_fecha = con_fecha + 1
        if revisadas == 200:
            break
    return revisadas > 0 and con_fecha * 2 >= revisadas

def es_encabezado_capitulo(linea):
    texto = linea.strip().upper()
    empieza = texto.startswith("CAPÍTULO") or texto.startswith("CAPITULO")
    return empieza and len(texto.split()) <= 3

def es_titulo_mayusculas(linea):
    texto = linea.strip()
    if texto == "" or len(texto.split()) > 8:
        return False
    tiene_letra = False
    for caracter in texto:
        if caracter.isalpha():
            tiene_letra = True
            if caracter.islower():
                return False
    return tiene_letra

def extraer_años(linea):
    años = []
    grupo = ""
    for caracter in linea + " ":
        if caracter.isdigit():
            grupo = grupo + caracter
        else:
            if len(grupo) == 4 and 1000 <= int(grupo) <= 2099:
                años.append(grupo)
            grupo = ""
    return años

def analizar_patrones(lineas):
    es_log = es_archivo_log(lineas)
    palabras_error = {}
    for palabra in PALABRAS_ERROR:
        palabras_error[palabra] = 0
    niveles = {}
    codigos = {}
    fechas = {}
    literarios = {"capitulos": 0, "titulos": 0, "preguntas": 0,
                  "exclamaciones": 0, "citas": 0}
    años = {}

    for linea in lineas:
        minuscula = linea.lower()
        for palabra in PALABRAS_ERROR:
            if palabra in minuscula:
                palabras_error[palabra] = palabras_error[palabra] + 1

        if es_log:
            nivel = extraer_nivel_log(linea)
            if nivel != "":
                sumar_uno(niveles, nivel)
            codigo = extraer_codigo_http(linea)
            if codigo != "":
                sumar_uno(codigos, codigo)
            fecha = extraer_fecha_log(linea)
            if fecha != "":
                sumar_uno(fechas, fecha)
        else:
            if es_encabezado_capitulo(linea):
                literarios["capitulos"] = literarios["capitulos"] + 1
            elif es_titulo_mayusculas(linea):
                literarios["titulos"] = literarios["titulos"] + 1
            literarios["preguntas"] = literarios["preguntas"] + linea.count("¿")
            literarios["exclamaciones"] = literarios["exclamaciones"] + linea.count("¡")
            literarios["citas"] = literarios["citas"] + linea.count("«")
            for anio in extraer_años(linea):
                sumar_uno(años, anio)

    resultado = {
        "es_log": es_log,
        "palabras_error": palabras_error,
        "niveles": niveles,
        "codigos": codigos,
        "fechas": fechas,
        "literarios": literarios,
        "años": años,
    }
    return resultado

def contar_errores_http(codigos):
    errores_cliente = 0
    errores_servidor = 0
    for codigo in codigos:
        if codigo.startswith("4"):
            errores_cliente = errores_cliente + codigos[codigo]
        elif codigo.startswith("5"):
            errores_servidor = errores_servidor + codigos[codigo]
    return errores_cliente, errores_servidor


def buscar_patron(lineas, patron, max_ejemplos=3):
    patron_minuscula = patron.lower()
    cantidad = 0
    ejemplos = []
    numero = 1
    for linea in lineas:
        if patron_minuscula in linea.lower():
            cantidad = cantidad + 1
            if len(ejemplos) < max_ejemplos:
                ejemplos.append((numero, linea))
        numero = numero + 1
    return cantidad, ejemplos

def longitudes_de_lineas(lineas):
    """Lista con la cantidad de caracteres de cada línea."""
    longitudes = []
    for linea in lineas:
        longitudes.append(len(linea))
    return longitudes

def calcular_intervalos(longitud_maxima):
    cantidad = (longitud_maxima + ANCHO_INTERVALO - 1) // ANCHO_INTERVALO
    if cantidad < 1:
        cantidad = 1
    hay_recorte = cantidad > MAX_INTERVALOS
    if hay_recorte:
        cantidad = MAX_INTERVALOS

    bordes = [-0.5]
    etiquetas = []
    for i in range(cantidad):
        desde = i * ANCHO_INTERVALO + 1
        if i == 0:
            desde = 0
        hasta = (i + 1) * ANCHO_INTERVALO
        bordes.append(hasta + 0.5)
        etiquetas.append(str(desde) + "-" + str(hasta))

    if hay_recorte:
        etiquetas[-1] = str((cantidad - 1) * ANCHO_INTERVALO + 1) + "+"
    limite = cantidad * ANCHO_INTERVALO
    return bordes, etiquetas, limite

def agrupar_longitudes(longitudes):
    maximo = 0
    for longitud in longitudes:
        if longitud > maximo:
            maximo = longitud
    bordes, etiquetas, limite = calcular_intervalos(maximo)

    cantidades = []
    for _ in etiquetas:
        cantidades.append(0)
    ajustadas = []
    for longitud in longitudes:
        valor = min(longitud, limite)
        ajustadas.append(valor)
        if valor == 0:
            indice = 0
        else:
            indice = (valor - 1) // ANCHO_INTERVALO
        cantidades[indice] = cantidades[indice] + 1
    return etiquetas, cantidades, bordes, ajustadas

def detectar_delimitador(primera_linea):
    mejor = ","
    mayor = -1
    for candidato in (",", ";", "\t", "|"):
        veces = primera_linea.count(candidato)
        if veces > mayor:
            mejor = candidato
            mayor = veces
    return mejor


def separar_registros_csv(contenido, separador):
    filas = []
    fila = []
    celda = ""
    en_comillas = False
    i = 0
    total = len(contenido)
    while i < total:
        caracter = contenido[i]
        if en_comillas:
            if caracter == '"':
                if i + 1 < total and contenido[i + 1] == '"':
                    celda = celda + '"'
                    i = i + 1
                else:
                    en_comillas = False
            else:
                celda = celda + caracter
        elif caracter == '"':
            en_comillas = True
        elif caracter == separador:
            fila.append(celda)
            celda = ""
        elif caracter == "\n":
            fila.append(celda)
            filas.append(fila)
            fila = []
            celda = ""
        elif caracter != "\r":
            celda = celda + caracter
        i = i + 1

    if celda != "" or len(fila) > 0:
        fila.append(celda)
        filas.append(fila)
    return filas


def cargar_csv(ruta):
    contenido, codificacion = leer_contenido(ruta)
    primera_linea = contenido.split("\n")[0]
    if primera_linea.strip() == "":
        raise ValueError("El archivo está vacío o la primera línea no tiene encabezados.")
    delimitador = detectar_delimitador(primera_linea)
    registros = separar_registros_csv(contenido, delimitador)

    encabezados = []
    numero = 1
    for celda in registros[0]:
        nombre = celda.strip()
        if nombre == "":
            nombre = "columna_" + str(numero)
        encabezados.append(nombre)
        numero = numero + 1

    filas = []
    total_columnas = len(encabezados)
    for registro in registros[1:]:
        if "".join(registro).strip() == "":
            continue
        fila_limpia = []
        for i in range(total_columnas):
            if i < len(registro):
                fila_limpia.append(registro[i].strip())
            else:
                fila_limpia.append("")
        filas.append(fila_limpia)

    if len(filas) == 0:
        raise ValueError("El archivo solo tiene encabezados, no tiene registros.")

    datos = {
        "nombre": os.path.basename(ruta),
        "ruta": ruta,
        "encabezados": encabezados,
        "filas": filas,
        "delimitador": delimitador,
        "codificacion": codificacion,
    }
    return datos


def es_nulo(texto):
    return texto.strip().lower() in VALORES_NULOS


def convertir_a_numero(texto):
    if es_nulo(texto):
        return None
    texto = texto.strip().replace(" ", "")
    if "," in texto and "." in texto:
        if texto.rfind(",") > texto.rfind("."):
            texto = texto.replace(".", "").replace(",", ".")   # 1.200,5
        else:
            texto = texto.replace(",", "")                     # 1,200.5
    elif texto.count(",") == 1:
        texto = texto.replace(",", ".")                        # 3,5
    try:
        numero = float(texto)
    except ValueError:
        return None
    # float() acepta 'inf' y 'nan', que no son datos útiles
    if numero != numero or numero == float("inf") or numero == float("-inf"):
        return None
    return numero


def obtener_columna(datos, indice):
    valores = []
    for fila in datos["filas"]:
        valores.append(fila[indice])
    return valores


def tipo_de_columna(datos, indice):
    no_nulos = 0
    numericos = 0
    for valor in obtener_columna(datos, indice):
        if not es_nulo(valor):
            no_nulos = no_nulos + 1
            if convertir_a_numero(valor) is not None:
                numericos = numericos + 1
    if no_nulos == 0:
        return "vacía"
    if numericos >= 0.9 * no_nulos:
        return "numérica"
    return "texto"


def tipos_de_columnas(datos):
    tipos = []
    for i in range(len(datos["encabezados"])):
        tipos.append(tipo_de_columna(datos, i))
    return tipos


def limpiar_numeros(valores):
    numeros = []
    descartados = 0
    for valor in valores:
        numero = convertir_a_numero(valor)
        if numero is None:
            descartados = descartados + 1
        else:
            numeros.append(numero)
    return numeros, descartados


def calcular_mediana(numeros):
    ordenados = sorted(numeros)
    n = len(ordenados)
    mitad = n // 2
    if n % 2 == 1:
        return ordenados[mitad]
    return (ordenados[mitad - 1] + ordenados[mitad]) / 2


def calcular_estadisticas(numeros):
    if len(numeros) == 0:
        return None
    suma = 0.0
    maximo = numeros[0]
    minimo = numeros[0]
    for numero in numeros:
        suma = suma + numero
        if numero > maximo:
            maximo = numero
        if numero < minimo:
            minimo = numero
    estadisticas = {
        "validos": len(numeros),
        "promedio": suma / len(numeros),
        "mediana": calcular_mediana(numeros),
        "maximo": maximo,
        "minimo": minimo,
    }
    return estadisticas


def pares_para_tendencia(datos, indice_x, indice_y, x_es_numerica):
    grupos = {}
    descartadas = 0
    for fila in datos["filas"]:
        texto_x = fila[indice_x]
        y = convertir_a_numero(fila[indice_y])
        if es_nulo(texto_x) or y is None:
            descartadas = descartadas + 1
            continue
        if x_es_numerica:
            x = convertir_a_numero(texto_x)
            if x is None:
                descartadas = descartadas + 1
                continue
        else:
            x = texto_x
        if x in grupos:
            grupos[x].append(y)
        else:
            grupos[x] = [y]
    return grupos, descartadas


def hay_valores_repetidos(grupos):
    for x in grupos:
        if len(grupos[x]) > 1:
            return True
    return False


def resumir_grupos(grupos, metodo, ordenar):
    claves = list(grupos.keys())
    if ordenar:
        claves = sorted(claves)
    xs = []
    ys = []
    for x in claves:
        total = 0.0
        for y in grupos[x]:
            total = total + y
        if metodo == "promedio":
            total = total / len(grupos[x])
        xs.append(x)
        ys.append(total)
    return xs, ys


def enteros_si_es_posible(valores):
    for valor in valores:
        if valor != int(valor):
            return valores
    enteros = []
    for valor in valores:
        enteros.append(int(valor))
    return enteros


def promedio_movil(valores, ventana):
    resultado = []
    suma = 0.0
    for i in range(len(valores)):
        suma = suma + valores[i]
        if i >= ventana:
            suma = suma - valores[i - ventana]
        if i >= ventana - 1:
            resultado.append(suma / ventana)
    return resultado

def contar_categorias(valores):
    conteo = {}
    nulos = 0
    for valor in valores:
        if es_nulo(valor):
            nulos = nulos + 1
        else:
            sumar_uno(conteo, valor)
    return conteo, nulos


def agrupar_otros(conteo, maximo):
    total = 0
    for categoria in conteo:
        total = total + conteo[categoria]

    if len(conteo) <= maximo + 1:
        pares = top_n(conteo, len(conteo))
    else:
        pares = top_n(conteo, maximo)

    etiquetas = []
    cantidades = []
    suma_mostrada = 0
    for categoria, cantidad in pares:
        etiquetas.append(categoria)
        cantidades.append(cantidad)
        suma_mostrada = suma_mostrada + cantidad
    if suma_mostrada < total:
        etiquetas.append("Otros")
        cantidades.append(total - suma_mostrada)
    return etiquetas, cantidades


def pares_numericos(datos, indice_x, indice_y):
    xs = []
    ys = []
    filas_usadas = []
    descartadas = 0
    for i in range(len(datos["filas"])):
        fila = datos["filas"][i]
        x = convertir_a_numero(fila[indice_x])
        y = convertir_a_numero(fila[indice_y])
        if x is None or y is None:
            descartadas = descartadas + 1
        else:
            xs.append(x)
            ys.append(y)
            filas_usadas.append(i)
    return xs, ys, filas_usadas, descartadas


def agrupar_puntos(datos, indice_categoria, xs, ys, filas_usadas, maximo):
    categorias = []
    conteo = {}
    for indice_fila in filas_usadas:
        categoria = datos["filas"][indice_fila][indice_categoria]
        if es_nulo(categoria):
            categoria = "Sin dato"
        categorias.append(categoria)
        sumar_uno(conteo, categoria)

    elegidas = []
    for categoria, _ in top_n(conteo, maximo):
        elegidas.append(categoria)

    grupos = {}
    for categoria in elegidas:
        grupos[categoria] = ([], [])
    if len(conteo) > maximo:
        grupos["Otros"] = ([], [])
    for i in range(len(xs)):
        categoria = categorias[i]
        if categoria not in elegidas:
            categoria = "Otros"
        grupos[categoria][0].append(xs[i])
        grupos[categoria][1].append(ys[i])

    resultado = []
    for nombre in grupos:
        resultado.append((nombre, grupos[nombre][0], grupos[nombre][1]))
    return resultado

def correlacion_pearson(xs, ys):
    n = len(xs)
    if n < 2:
        return None
    media_x = 0.0
    media_y = 0.0
    for i in range(n):
        media_x = media_x + xs[i]
        media_y = media_y + ys[i]
    media_x = media_x / n
    media_y = media_y / n

    numerador = 0.0
    suma_cuadrados_x = 0.0
    suma_cuadrados_y = 0.0
    for i in range(n):
        dx = xs[i] - media_x
        dy = ys[i] - media_y
        numerador = numerador + dx * dy
        suma_cuadrados_x = suma_cuadrados_x + dx * dx
        suma_cuadrados_y = suma_cuadrados_y + dy * dy
    if suma_cuadrados_x == 0 or suma_cuadrados_y == 0:
        return None
    return numerador / (suma_cuadrados_x * suma_cuadrados_y) ** 0.5

def interpretar_correlacion(r):
    if r is None:
        return "no se puede calcular"
    fuerza = abs(r)
    if fuerza >= 0.7:
        texto = "fuerte"
    elif fuerza >= 0.4:
        texto = "moderada"
    elif fuerza >= 0.2:
        texto = "débil"
    else:
        return "prácticamente nula"
    if r > 0:
        return texto + " positiva"
    return texto + " negativa"

def crear_figura(ancho, alto):
    """Crea una figura y sus ejes con el estilo común del proyecto."""
    figura, ejes = plt.subplots(figsize=(ancho, alto))
    figura.patch.set_facecolor(COLOR_FONDO)
    ejes.set_facecolor(COLOR_FONDO)
    for lado in ("top", "right"):
        ejes.spines[lado].set_visible(False)
    for lado in ("left", "bottom"):
        ejes.spines[lado].set_color(COLOR_EJE)
    ejes.tick_params(colors=COLOR_TEXTO_SECUNDARIO, labelsize=9)
    ejes.set_axisbelow(True)
    return figura, ejes

def poner_titulos(ejes, titulo, subtitulo, etiqueta_x, etiqueta_y):
    ejes.set_title(titulo, loc="left", fontsize=13, fontweight="bold",
                   color=COLOR_TEXTO, pad=22)
    ejes.text(0, 1.02, subtitulo, transform=ejes.transAxes, fontsize=9,
              color=COLOR_TEXTO_SECUNDARIO)
    ejes.set_xlabel(etiqueta_x, color=COLOR_TEXTO_SECUNDARIO, fontsize=10)
    ejes.set_ylabel(etiqueta_y, color=COLOR_TEXTO_SECUNDARIO, fontsize=10)

def guardar_y_mostrar(figura, nombre_archivo):
    os.makedirs(RUTA_SALIDAS, exist_ok=True)
    ruta = os.path.join(RUTA_SALIDAS, nombre_archivo + ".png")
    figura.tight_layout()
    figura.savefig(ruta, dpi=150, facecolor=COLOR_FONDO)
    # El backend 'agg' no abre ventanas (por ejemplo, en un servidor sin pantalla)
    if matplotlib.get_backend().lower() != "agg":
        print("  (Cierre la ventana del gráfico para continuar)")
        plt.show()
    plt.close(figura)
    return ruta

def grafico_barras_palabras(pares, nombre_fuente, nombre_archivo):
    palabras = []
    cantidades = []
    for palabra, cantidad in pares:
        palabras.append(palabra)
        cantidades.append(cantidad)

    figura, ejes = crear_figura(9, 5.5)
    barras = ejes.barh(palabras, cantidades, color=COLORES_SERIES[0],
                       height=0.65, edgecolor=COLOR_FONDO, linewidth=2)
    ejes.invert_yaxis()
    ejes.grid(axis="x", color=COLOR_CUADRICULA, linewidth=0.8)
    ejes.spines["left"].set_visible(False)
    ejes.tick_params(axis="y", length=0, labelsize=10, labelcolor=COLOR_TEXTO)

    maximo = max(cantidades)
    for i in range(len(barras)):
        barra = barras[i]
        ejes.text(barra.get_width() + maximo * 0.01,
                  barra.get_y() + barra.get_height() / 2,
                  formatear_numero(cantidades[i]), va="center", fontsize=9,
                  color=COLOR_TEXTO_SECUNDARIO)
    ejes.set_xlim(0, maximo * 1.12)

    poner_titulos(ejes, "Las " + str(len(pares)) + " palabras más frecuentes",
                  "Archivo: " + nombre_fuente + "  ·  sin conectores ni artículos",
                  "Número de apariciones", "")
    return guardar_y_mostrar(figura, nombre_archivo)


def histograma_longitudes(longitudes, bordes, etiquetas, nombre_fuente,
                          nombre_archivo):
    figura, ejes = crear_figura(10, 5.5)
    conteos, _, _ = ejes.hist(longitudes, bins=bordes, color=COLORES_SERIES[0],
                              edgecolor=COLOR_FONDO, linewidth=2)
    ejes.grid(axis="y", color=COLOR_CUADRICULA, linewidth=0.8)

    centros = []
    for i in range(len(etiquetas)):
        centros.append((bordes[i] + bordes[i + 1]) / 2)
    rotacion = 0
    if len(etiquetas) > 8:
        rotacion = 45
    ejes.set_xticks(centros)
    ejes.set_xticklabels(etiquetas, rotation=rotacion)

    total = len(longitudes)
    for i in range(len(conteos)):
        if conteos[i] > 0:
            texto = (formatear_numero(conteos[i]) + "\n("
                     + "{:.1f}".format(porcentaje(conteos[i], total)) + " %)")
            ejes.text(centros[i], conteos[i], texto, ha="center", va="bottom",
                      fontsize=8, color=COLOR_TEXTO_SECUNDARIO)
    ejes.set_ylim(0, max(conteos) * 1.18)

    poner_titulos(ejes, "Distribución de la longitud de las líneas",
                  "Archivo: " + nombre_fuente + "  ·  " + formatear_numero(total)
                  + " líneas en grupos de 50 caracteres",
                  "Caracteres por línea", "Número de líneas")
    return guardar_y_mostrar(figura, nombre_archivo)


def grafico_lineas(xs, ys, x_es_texto, nombre_x, nombre_y, nombre_fuente,
                   nombre_archivo, ventana, movil):
    figura, ejes = crear_figura(11, 5.5)
    if x_es_texto:
        posiciones = list(range(len(xs)))
    else:
        posiciones = xs

    if movil is None:
        ejes.plot(posiciones, ys, color=COLORES_SERIES[0], linewidth=2,
                  label=nombre_y)
    else:
        ejes.plot(posiciones, ys, color=COLOR_APAGADO, linewidth=0.8,
                  alpha=0.6, label=nombre_y + " (dato original)")
        ejes.plot(posiciones[ventana - 1:], movil, color=COLORES_SERIES[0],
                  linewidth=2.2,
                  label="Promedio móvil de " + str(ventana) + " registros")
        minimo_y = min(ys)
        maximo_y = max(ys)
        rango = maximo_y - minimo_y
        ejes.set_ylim(minimo_y - rango * 0.05, maximo_y + rango * 0.22)
        ejes.legend(frameon=False, fontsize=9, loc="upper left", ncol=2,
                    labelcolor=COLOR_TEXTO_SECUNDARIO)

    if not x_es_texto and len(xs) <= 15:
        ejes.set_xticks(xs)
        ejes.plot(posiciones, ys, "o", color=COLORES_SERIES[0], markersize=8,
                  markeredgecolor=COLOR_FONDO, markeredgewidth=2)

    if x_es_texto:
        paso = max(1, len(xs) // MAX_ETIQUETAS_EJE_X)
        marcas = []
        etiquetas = []
        for i in range(0, len(xs), paso):
            marcas.append(i)
            etiquetas.append(str(xs[i]))
        ejes.set_xticks(marcas)
        ejes.set_xticklabels(etiquetas, rotation=35, ha="right")
        ejes.set_xlim(-1, len(xs))

    ejes.grid(axis="y", color=COLOR_CUADRICULA, linewidth=0.8)
    poner_titulos(ejes, "Evolución de " + nombre_y + " según " + nombre_x,
                  "Archivo: " + nombre_fuente + "  ·  " + formatear_numero(len(xs))
                  + " puntos", nombre_x, nombre_y)
    return guardar_y_mostrar(figura, nombre_archivo)


def etiqueta_porcentaje(valor):
    if valor < 4:
        return ""
    return "{:.1f} %".format(valor)


def grafico_pastel(etiquetas, cantidades, nombre_columna, nombre_fuente,
                   nombre_archivo):
    total = 0
    for cantidad in cantidades:
        total = total + cantidad

    colores = []
    for i in range(len(etiquetas)):
        if etiquetas[i] == "Otros":
            colores.append(COLOR_OTROS)
        else:
            colores.append(COLORES_SERIES[i % len(COLORES_SERIES)])

    figura, ejes = crear_figura(9.5, 6)
    porciones, _, textos = ejes.pie(
        cantidades, colors=colores, autopct=etiqueta_porcentaje, startangle=90,
        counterclock=False, pctdistance=0.72,
        wedgeprops={"edgecolor": COLOR_FONDO, "linewidth": 2})
    ejes.axis("equal")

    for i in range(len(textos)):
        if colores[i] in ("#eda100", COLOR_OTROS):
            textos[i].set_color(COLOR_TEXTO)
        else:
            textos[i].set_color("white")
        textos[i].set_fontsize(10)
        textos[i].set_fontweight("bold")

    leyenda = []
    for i in range(len(etiquetas)):
        leyenda.append("{}  —  {} ({:.1f} %)".format(
            etiquetas[i], formatear_numero(cantidades[i]),
            porcentaje(cantidades[i], total)))
    ejes.legend(porciones, leyenda, loc="center left", bbox_to_anchor=(1.0, 0.5),
                frameon=False, fontsize=10, labelcolor=COLOR_TEXTO)

    ejes.set_title("Participación por " + nombre_columna, loc="left",
                   fontsize=13, fontweight="bold", color=COLOR_TEXTO)
    ejes.text(0, -0.04, "Archivo: " + nombre_fuente + "  ·  "
              + formatear_numero(total) + " registros con dato",
              transform=ejes.transAxes, fontsize=9, color=COLOR_TEXTO_SECUNDARIO)
    return guardar_y_mostrar(figura, nombre_archivo)


def grafico_dispersion(grupos, nombre_x, nombre_y, r, interpretacion,
                       nombre_fuente, nombre_archivo):
    figura, ejes = crear_figura(9, 6)
    total = 0
    for _, xs_grupo, _ in grupos:
        total = total + len(xs_grupo)
    tamano = 42
    if total > 800:
        tamano = 24    

    for i in range(len(grupos)):
        nombre, xs, ys = grupos[i]
        if nombre == "Otros":
            color = COLOR_OTROS
        else:
            color = COLORES_SERIES[i % len(COLORES_SERIES)]
        ejes.scatter(xs, ys, s=tamano, color=color, alpha=0.85,
                     edgecolors=COLOR_FONDO, linewidths=0.8,
                     label=nombre + " (" + formatear_numero(len(xs)) + ")")

    if len(grupos) > 1:
        ejes.legend(frameon=False, fontsize=9, labelcolor=COLOR_TEXTO, loc="best")
    ejes.grid(color=COLOR_CUADRICULA, linewidth=0.8)

    if r is None:
        texto_r = "r no calculable"
    else:
        texto_r = "r = {:.2f} (correlación {})".format(r, interpretacion)
    poner_titulos(ejes, nombre_y + " vs. " + nombre_x + "  ·  " + texto_r,
                  "Archivo: " + nombre_fuente + "  ·  " + formatear_numero(total)
                  + " pares válidos", nombre_x, nombre_y)
    return guardar_y_mostrar(figura, nombre_archivo)

def abrir_texto(directorio):
    ruta = seleccionar_archivo(directorio, ".txt")
    if ruta is None:
        return None
    try:
        datos = cargar_texto(ruta)
    except FileNotFoundError:
        print("  [!] El archivo ya no existe: " + ruta)
        return None
    except PermissionError:
        print("  [!] No tiene permisos para leer: " + ruta)
        return None
    except OSError as error:
        print("  [!] No se pudo leer el archivo: " + str(error))
        return None

    print("\n  Archivo cargado: " + datos["nombre"] + "  ("
          + formatear_numero(len(datos["lineas"])) + " líneas, codificación "
          + datos["codificacion"] + ")")
    if datos["licencia_omitida"]:
        print("  Se detectó un libro del Proyecto Gutenberg: se omitió la "
              "licencia en inglés del inicio y del final.")
    if len(datos["lineas"]) == 0:
        print("  [!] El archivo está vacío.")
    return datos


def mostrar_menu_texto(nombre_archivo):
    imprimir_titulo("PROCESAR BITÁCORAS / TEXTOS REALES (.txt)")
    print("  Archivo actual: " + nombre_archivo)
    print("  1. Resumen estadístico del texto")
    print("  2. Extracción de patrones (logs y textos literarios)")
    print("  3. Gráfico 1 - Frecuencia de palabras clave (barras horizontales)")
    print("  4. Gráfico 2 - Distribución de longitud de líneas (histograma)")
    print("  5. Cargar otro archivo .txt")
    print("  6. Volver al menú principal")

def menu_textos(directorio):
    imprimir_titulo("SELECCIONAR ARCHIVO .txt")
    datos = abrir_texto(directorio)
    if datos is None:
        return

    while True:
        mostrar_menu_texto(datos["nombre"])
        opcion = pedir_opcion("Seleccione una opción: ", 1, 6)
        if opcion == 6:
            return
        try:
            if opcion == 1:
                opcion_resumen_texto(datos)
            elif opcion == 2:
                opcion_patrones(datos)
            elif opcion == 3:
                opcion_grafico_palabras(datos)
            elif opcion == 4:
                opcion_grafico_longitudes(datos)
            elif opcion == 5:
                nuevos = abrir_texto(directorio)
                if nuevos is not None:
                    datos = nuevos
        except (EOFError, KeyboardInterrupt):
            raise
        except Exception as error:
            print("  [!] Ocurrió un error inesperado: " + str(error))
        pausar()


def opcion_resumen_texto(datos):
    resumen = calcular_resumen(datos["lineas"])
    conteo = datos["conteo_palabras"]

    imprimir_titulo("RESUMEN ESTADÍSTICO - " + datos["nombre"])
    print("  Total de líneas ...................... "
          + formatear_numero(resumen["total_lineas"]))
    print("     de ellas vacías ................... "
          + formatear_numero(resumen["lineas_vacias"]))
    print("  Total de palabras .................... "
          + formatear_numero(resumen["total_palabras"]))
    print("  Caracteres (con espacios) ............ "
          + formatear_numero(resumen["caracteres_con_espacios"]))
    print("  Caracteres (sin espacios) ............ "
          + formatear_numero(resumen["caracteres_sin_espacios"]))
    print("  Promedio de caracteres por línea ..... "
          + formatear_numero(resumen["promedio_caracteres_linea"], 1)
          + "  (sin contar líneas vacías)")
    print("  Palabras distintas (sin conectores) .. "
          + formatear_numero(len(conteo)))

    imprimir_subtitulo("Top " + str(TOP_PALABRAS_RESUMEN)
                       + " de palabras más repetidas (excluyendo conectores)")
    if len(conteo) == 0:
        print("  No se encontraron palabras.")
        return
    posicion = 1
    for palabra, cantidad in top_n(conteo, TOP_PALABRAS_RESUMEN):
        print("  {}. {:<20} {:>10}".format(posicion, palabra, formatear_numero(cantidad)))
        posicion = posicion + 1


def imprimir_conteo(diccionario, total, limite):
    mostrados = 0
    for clave in diccionario:
        if mostrados == limite:
            print("  ... y " + str(len(diccionario) - limite) + " más")
            break
        print("  {:<14} {:>10}   ({:5.1f} %)".format(
            clave, formatear_numero(diccionario[clave]),
            porcentaje(diccionario[clave], total)))
        mostrados = mostrados + 1

def ordenar_conteo(diccionario):
    ordenado = {}
    for clave, cantidad in top_n(diccionario, len(diccionario)):
        ordenado[clave] = cantidad
    return ordenado


def opcion_patrones(datos):
    lineas = datos["lineas"]
    patrones = analizar_patrones(lineas)
    total = len(lineas)

    imprimir_titulo("EXTRACCIÓN DE PATRONES - " + datos["nombre"])
    if patrones["es_log"]:
        print("  El archivo SÍ tiene formato de bitácora (log).")
    else:
        print("  El archivo NO es una bitácora: se analiza como texto literario.")

    niveles = patrones["niveles"]
    if len(niveles) > 0:
        imprimir_subtitulo("Niveles de severidad encontrados")
        imprimir_conteo(ordenar_conteo(niveles), total, 15)

    codigos = patrones["codigos"]
    if len(codigos) > 0:
        total_codigos = 0
        for codigo in codigos:
            total_codigos = total_codigos + codigos[codigo]
        imprimir_subtitulo("Códigos de estado HTTP (de mayor a menor)")
        imprimir_conteo(ordenar_conteo(codigos), total_codigos, 15)
        errores_4xx, errores_5xx = contar_errores_http(codigos)
        print("\n  Errores de cliente (4xx): " + formatear_numero(errores_4xx)
              + "   |   Errores de servidor (5xx): " + formatear_numero(errores_5xx))
        if "404" in codigos:
            print("  Páginas no encontradas (404): " + formatear_numero(codigos["404"]))

    fechas = patrones["fechas"]
    if len(fechas) > 0:
        imprimir_subtitulo("Registros por fecha (en orden de aparición)")
        imprimir_conteo(fechas, total, 15)
        fecha_pico, cantidad_pico = top_n(fechas, 1)[0]
        print("\n  Fecha con más registros: " + fecha_pico + " ("
              + formatear_numero(cantidad_pico) + ")")

    if not patrones["es_log"]:
        literarios = patrones["literarios"]
        imprimir_subtitulo("Patrones literarios")
        print("  Encabezados de capítulo (CAPÍTULO ...) .. "
              + formatear_numero(literarios["capitulos"]))
        print("  Títulos en MAYÚSCULAS (poemas, partes) .. "
              + formatear_numero(literarios["titulos"]))
        print("  Preguntas (¿) ........................... "
              + formatear_numero(literarios["preguntas"]))
        print("  Exclamaciones (¡) ....................... "
              + formatear_numero(literarios["exclamaciones"]))
        print("  Citas o nombres entre comillas («) ...... "
              + formatear_numero(literarios["citas"]))
        años = patrones["anios"]
        if len(años) > 0:
            print("\n  Años mencionados (los 8 más frecuentes):")
            for anio, cantidad in top_n(años, 8):
                print("     " + anio + ": " + formatear_numero(cantidad) + " vez/veces")
        else:
            print("\n  No se mencionan años (fechas de 4 cifras).")

    imprimir_subtitulo("Líneas que contienen palabras clave de error")
    imprimir_conteo(patrones["palabras_error"], total, 20)
    imprimir_subtitulo("Búsqueda personalizada")
    while True:
        patron = pedir_texto("Texto o fecha a buscar (ej. 404, ERROR, Bogotá, "
                             "1858) [Enter = terminar]: ")
        if patron == "":
            break
        cantidad, ejemplos = buscar_patron(lineas, patron)
        print("  '" + patron + "' aparece en " + formatear_numero(cantidad)
              + " línea(s) (" + "{:.2f}".format(porcentaje(cantidad, total))
              + " % del archivo).")
        for numero, texto in ejemplos:
            print("     línea " + str(numero) + ": " + recortar_texto(texto.strip(), 95))


def opcion_grafico_palabras(datos):
    conteo = datos["conteo_palabras"]
    if len(conteo) == 0:
        print("  [!] El archivo no tiene palabras para graficar.")
        return
    pares = top_n(conteo, TOP_PALABRAS_GRAFICO)

    imprimir_titulo("GRÁFICO 1 - FRECUENCIA DE PALABRAS")
    posicion = 1
    for palabra, cantidad in pares:
        print("  {:>2}. {:<20} {:>10}".format(posicion, palabra, formatear_numero(cantidad)))
        posicion = posicion + 1
    nombre = "g1_barh_palabras_" + nombre_seguro(os.path.splitext(datos["nombre"])[0])
    ruta = grafico_barras_palabras(pares, datos["nombre"], nombre)
    print("\n  Gráfico guardado en: " + ruta_relativa(ruta))


def opcion_grafico_longitudes(datos):
    lineas = datos["lineas"]
    if len(lineas) == 0:
        print("  [!] El archivo no tiene líneas para graficar.")
        return

    imprimir_titulo("GRÁFICO 2 - LONGITUD DE LÍNEAS")
    incluir_vacias = pedir_si_no("¿Incluir las líneas vacías (0 caracteres)?")
    seleccion = []
    for linea in lineas:
        if incluir_vacias or linea.strip() != "":
            seleccion.append(linea)
    if len(seleccion) == 0:
        print("  [!] No quedan líneas para graficar.")
        return

    longitudes = longitudes_de_lineas(seleccion)
    etiquetas, cantidades, bordes, ajustadas = agrupar_longitudes(longitudes)

    print("\n  Grupo (caracteres)    Líneas      %")
    for i in range(len(etiquetas)):
        print("  {:<18} {:>10}  {:5.1f}".format(
            etiquetas[i], formatear_numero(cantidades[i]),
            porcentaje(cantidades[i], len(longitudes))))
    nombre = "g2_hist_longitudes_" + nombre_seguro(os.path.splitext(datos["nombre"])[0])
    ruta = histograma_longitudes(ajustadas, bordes, etiquetas, datos["nombre"], nombre)
    print("\n  Gráfico guardado en: " + ruta_relativa(ruta))


def abrir_csv(directorio):
    ruta = seleccionar_archivo(directorio, ".csv")
    if ruta is None:
        return None
    try:
        datos = cargar_csv(ruta)
    except FileNotFoundError:
        print("  [!] El archivo ya no existe: " + ruta)
        return None
    except PermissionError:
        print("  [!] No tiene permisos para leer: " + ruta)
        return None
    except ValueError as error:
        print("  [!] El archivo no tiene un formato CSV válido: " + str(error))
        return None
    except OSError as error:
        print("  [!] No se pudo leer el archivo: " + str(error))
        return None

    datos["tipos"] = tipos_de_columnas(datos)
    print("\n  Archivo cargado: " + datos["nombre"] + "  ("
          + formatear_numero(len(datos["filas"])) + " registros, "
          + str(len(datos["encabezados"])) + " columnas, separador '"
          + datos["delimitador"] + "')")
    return datos


def mostrar_menu_csv(nombre_archivo):
    imprimir_titulo("ANALIZAR DATASET DE DATOS ABIERTOS (.csv)")
    print("  Archivo actual: " + nombre_archivo)
    print("  1. Vista previa de datos")
    print("  2. Estadísticas descriptivas de una columna")
    print("  3. Gráfico 3 - Evolución temporal / tendencia (líneas)")
    print("  4. Gráfico 4 - Comparación categórica (pastel)")
    print("  5. Gráfico 5 - Correlación de variables (dispersión)")
    print("  6. Cargar otro archivo .csv")
    print("  7. Volver al menú principal")

def menu_csv(directorio):
    imprimir_titulo("SELECCIONAR ARCHIVO .csv")
    datos = abrir_csv(directorio)
    if datos is None:
        return

    while True:
        mostrar_menu_csv(datos["nombre"])
        opcion = pedir_opcion("Seleccione una opción: ", 1, 7)
        if opcion == 7:
            return
        try:
            if opcion == 1:
                opcion_vista_previa(datos)
            elif opcion == 2:
                opcion_estadisticas(datos)
            elif opcion == 3:
                opcion_grafico_tendencia(datos)
            elif opcion == 4:
                opcion_grafico_categorias(datos)
            elif opcion == 5:
                opcion_grafico_correlacion(datos)
            elif opcion == 6:
                nuevos = abrir_csv(directorio)
                if nuevos is not None:
                    datos = nuevos
        except (EOFError, KeyboardInterrupt):
            raise
        except Exception as error:
            print("  [!] Ocurrió un error inesperado: " + str(error))
        pausar()

def mostrar_columnas(datos, solo_numericas):
    for i in range(len(datos["encabezados"])):
        if solo_numericas and datos["tipos"][i] != "numérica":
            continue
        print("    {:>2}. {:<24} ({})".format(i + 1, datos["encabezados"][i],
                                            datos["tipos"][i]))

def seleccionar_columna(datos, mensaje, solo_numericas):
    permitidas = []
    for i in range(len(datos["encabezados"])):
        if not solo_numericas or datos["tipos"][i] == "numérica":
            permitidas.append(i)
    if len(permitidas) == 0:
        print("  [!] El archivo no tiene columnas numéricas.")
        return None

    print("\n" + mensaje)
    mostrar_columnas(datos, solo_numericas)
    while True:
        respuesta = pedir_texto("Columna (número o nombre, 0 = cancelar): ")
        if respuesta == "0":
            return None
        indice = -1
        if respuesta.isdigit():
            indice = int(respuesta) - 1
        else:
            for i in range(len(datos["encabezados"])):
                if datos["encabezados"][i].lower() == respuesta.lower():
                    indice = i
        if indice in permitidas:
            return indice
        if solo_numericas and 0 <= indice < len(datos["encabezados"]):
            print("  [!] Esa columna no es numérica. Elija una de la lista.")
        else:
            print("  [!] Columna no válida. Intente de nuevo.")

def imprimir_tabla(encabezados, filas, numeros_fila):
    limpias = []
    for fila in filas:
        fila_limpia = []
        for celda in fila:
            fila_limpia.append(celda.replace("\n", " "))
        limpias.append(fila_limpia)
    filas = limpias

    anchos = []
    for i in range(len(encabezados)):
        ancho = len(encabezados[i])
        for fila in filas:
            if len(fila[i]) > ancho:
                ancho = len(fila[i])
        anchos.append(max(3, min(ancho, ANCHO_CELDA)))

    linea = "  {:>5} ".format("Fila")
    separador = "  ----- "
    for i in range(len(encabezados)):
        linea = linea + "| " + recortar_texto(encabezados[i], anchos[i]).ljust(anchos[i]) + " "
        separador = separador + "+" + "-" * (anchos[i] + 2)
    print(linea)
    print(separador)
    for j in range(len(filas)):
        linea = "  {:>5} ".format(numeros_fila[j])
        for i in range(len(encabezados)):
            linea = linea + "| " + recortar_texto(filas[j][i], anchos[i]).ljust(anchos[i]) + " "
        print(linea)

def nombre_base(datos):
    return nombre_seguro(os.path.splitext(datos["nombre"])[0])

def opcion_vista_previa(datos):
    filas = datos["filas"]
    total = len(filas)
    imprimir_titulo("VISTA PREVIA - " + datos["nombre"])
    print("  Registros: " + formatear_numero(total) + "   |   Columnas: "
          + str(len(datos["encabezados"])) + "   |   Separador: '"
          + datos["delimitador"] + "'   |   Codificación: " + datos["codificacion"])
    print("\n  Columnas y tipo de dato detectado:")
    mostrar_columnas(datos, False)

    if total <= FILAS_INICIO + FILAS_FINAL:
        imprimir_subtitulo("Todas las filas (" + str(total) + ")")
        imprimir_tabla(datos["encabezados"], filas, list(range(1, total + 1)))
        return

    imprimir_subtitulo("Primeras " + str(FILAS_INICIO) + " filas")
    imprimir_tabla(datos["encabezados"], filas[:FILAS_INICIO],
                   list(range(1, FILAS_INICIO + 1)))
    imprimir_subtitulo("Últimas " + str(FILAS_FINAL) + " filas")
    imprimir_tabla(datos["encabezados"], filas[total - FILAS_FINAL:],
                   list(range(total - FILAS_FINAL + 1, total + 1)))

def opcion_estadisticas(datos):
    """Limpia los nulos de una columna numérica y calcula sus estadísticas."""
    imprimir_titulo("ESTADÍSTICAS DESCRIPTIVAS")
    indice = seleccionar_columna(datos, "Columnas numéricas disponibles:", True)
    if indice is None:
        return
    numeros, descartados = limpiar_numeros(obtener_columna(datos, indice))
    estadisticas = calcular_estadisticas(numeros)
    if estadisticas is None:
        print("  [!] La columna no tiene valores numéricos válidos.")
        return

    imprimir_subtitulo("Columna: " + datos["encabezados"][indice])
    print("  Registros en el archivo ........... " + formatear_numero(len(datos["filas"])))
    print("  Nulos / vacíos eliminados ......... " + formatear_numero(descartados))
    print("  Total de registros válidos ........ " + formatear_numero(estadisticas["validos"]))
    print("  Promedio .......................... " + formatear_numero(estadisticas["promedio"]))
    print("  Mediana ........................... " + formatear_numero(estadisticas["mediana"]))
    print("  Valor máximo ...................... " + formatear_numero(estadisticas["maximo"]))
    print("  Valor mínimo ...................... " + formatear_numero(estadisticas["minimo"]))

def opcion_grafico_tendencia(datos):
    imprimir_titulo("GRÁFICO 3 - EVOLUCIÓN TEMPORAL / TENDENCIA")
    indice_x = seleccionar_columna(datos, "Eje X (ej. una fecha o un año):", False)
    if indice_x is None:
        return
    indice_y = seleccionar_columna(datos, "Eje Y (columna numérica):", True)
    if indice_y is None:
        return

    x_es_numerica = datos["tipos"][indice_x] == "numérica"
    grupos, descartadas = pares_para_tendencia(datos, indice_x, indice_y, x_es_numerica)
    if len(grupos) < 2:
        print("  [!] Se necesitan al menos 2 valores distintos en X para dibujar una línea.")
        return

    metodo = "promedio"
    if hay_valores_repetidos(grupos):
        print("\n  Hay valores de X repetidos. ¿Cómo combinar sus valores de Y?")
        print("    1. Promedio (ej. temperaturas)")
        print("    2. Suma (ej. ventas)")
        if pedir_opcion("  Opción: ", 1, 2) == 2:
            metodo = "suma"
    xs, ys = resumir_grupos(grupos, metodo, x_es_numerica)
    if x_es_numerica:
        xs = enteros_si_es_posible(xs)

    ventana = None
    movil = None
    if len(ys) >= 6:
        ventana = pedir_entero_opcional(
            "Promedio móvil: cantidad de registros a promediar (ej. 30) "
            "[Enter = omitir]: ", 2, len(ys) // 2)
        if ventana is not None:
            movil = promedio_movil(ys, ventana)

    nombre_x = datos["encabezados"][indice_x]
    nombre_y = datos["encabezados"][indice_y]
    print("\n  Puntos graficados: " + formatear_numero(len(xs))
          + "   |   Filas descartadas por datos nulos: " + formatear_numero(descartadas))
    print("  Primer punto: " + str(xs[0]) + " -> " + formatear_numero(ys[0])
          + "   |   Último punto: " + str(xs[-1]) + " -> " + formatear_numero(ys[-1]))
    nombre = ("g3_plot_" + nombre_base(datos) + "_" + nombre_seguro(nombre_y)
              + "_por_" + nombre_seguro(nombre_x))
    ruta = grafico_lineas(xs, ys, not x_es_numerica, nombre_x, nombre_y,
                          datos["nombre"], nombre, ventana, movil)
    print("\n  Gráfico guardado en: " + ruta_relativa(ruta))


def opcion_grafico_categorias(datos):
    imprimir_titulo("GRÁFICO 4 - COMPARACIÓN CATEGÓRICA")
    indice = seleccionar_columna(datos, "Columna categórica (ej. ciudad, tipo):", False)
    if indice is None:
        return
    nombre_columna = datos["encabezados"][indice]
    conteo, nulos = contar_categorias(obtener_columna(datos, indice))
    if len(conteo) == 0:
        print("  [!] La columna no tiene datos.")
        return
    if len(conteo) == 1:
        print("  [!] La columna tiene una sola categoría: el pastel sería un círculo completo.")
    if datos["tipos"][indice] == "numérica" and len(conteo) > 15:
        print("  [!] La columna es numérica y tiene " + str(len(conteo))
              + " valores distintos; un pastel no será útil.")
        if not pedir_si_no("¿Desea continuar de todos modos?"):
            return

    etiquetas, cantidades = agrupar_otros(conteo, MAX_CATEGORIAS_PASTEL)
    total = len(datos["filas"]) - nulos
    imprimir_subtitulo("Participación por " + nombre_columna)
    for i in range(len(etiquetas)):
        print("  {:<22} {:>8}   {:5.1f} %".format(
            recortar_texto(etiquetas[i], 22), formatear_numero(cantidades[i]),
            porcentaje(cantidades[i], total)))
    print("  Categorías distintas: " + str(len(conteo))
          + "   |   Registros sin dato (excluidos): " + formatear_numero(nulos))
    nombre = "g4_pie_" + nombre_base(datos) + "_" + nombre_seguro(nombre_columna)
    ruta = grafico_pastel(etiquetas, cantidades, nombre_columna, datos["nombre"], nombre)
    print("\n  Gráfico guardado en: " + ruta_relativa(ruta))

def opcion_grafico_correlacion(datos):
    imprimir_titulo("GRÁFICO 5 - CORRELACIÓN DE VARIABLES")
    indice_x = seleccionar_columna(datos, "Variable del eje X (numérica):", True)
    if indice_x is None:
        return
    indice_y = seleccionar_columna(datos, "Variable del eje Y (numérica):", True)
    if indice_y is None:
        return
    if indice_y == indice_x:
        print("  [!] Elija dos columnas distintas: una variable contra sí misma siempre da r = 1.")
        return
    xs, ys, filas_usadas, descartadas = pares_numericos(datos, indice_x, indice_y)
    if len(xs) < 2:
        print("  [!] No hay suficientes pares de datos válidos.")
        return
    r = correlacion_pearson(xs, ys)
    interpretacion = interpretar_correlacion(r)

    indice_color = seleccionar_columna(
        datos, "Opcional: columna categórica para colorear los puntos "
        "(0 = todos del mismo color):", False)
    if indice_color is None:
        grupos = [("Todos", xs, ys)]
    else:
        grupos = agrupar_puntos(datos, indice_color, xs, ys, filas_usadas,
                                MAX_CATEGORIAS_DISPERSION)

    nombre_x = datos["encabezados"][indice_x]
    nombre_y = datos["encabezados"][indice_y]
    imprimir_subtitulo(nombre_y + " vs. " + nombre_x)
    print("  Pares válidos: " + formatear_numero(len(xs))
          + "   |   Filas descartadas por nulos: " + formatear_numero(descartadas))
    if r is None:
        print("  Coeficiente de correlación: no se puede calcular (sin variación).")
    else:
        print("  Coeficiente de correlación de Pearson r = " + "{:.3f}".format(r)
              + "  ->  correlación " + interpretacion)
    if len(grupos) > 1:
        for nombre, xs_grupo, _ in grupos:
            print("    " + nombre + ": " + formatear_numero(len(xs_grupo)) + " puntos")
    nombre = ("g5_scatter_" + nombre_base(datos) + "_" + nombre_seguro(nombre_y)
              + "_vs_" + nombre_seguro(nombre_x))
    ruta = grafico_dispersion(grupos, nombre_x, nombre_y, r, interpretacion,
                              datos["nombre"], nombre)
    print("\n  Gráfico guardado en: " + ruta_relativa(ruta))

def mostrar_menu_principal(directorio):
    imprimir_titulo("ANALIZADOR DE DATOS REALES - MENÚ PRINCIPAL")
    print("  Carpeta de trabajo: " + directorio)
    print("  1. Explorar directorio")
    print("  2. Procesar bitácoras / textos reales (.txt)")
    print("  3. Analizar dataset de datos abiertos (.csv)")
    print("  4. Salir")


def main():
    directorio = RUTA_DATOS
    while True:
        mostrar_menu_principal(directorio)
        opcion = pedir_opcion("Seleccione una opción: ", 1, 4)
        if opcion == 1:
            directorio = explorar_directorio(directorio)
        elif opcion == 2:
            menu_textos(directorio)
        elif opcion == 3:
            menu_csv(directorio)
        else:
            print("\n¡Gracias por usar el analizador! Hasta pronto.")
            break

if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        print("\n\nPrograma finalizado por el usuario.")