# Analizador de datos reales (CLI en Python)

Aplicación de línea de comandos que procesa, analiza y grafica conjuntos de datos del mundo real:

- **Archivos `.txt`**: bitácoras (logs) de servidores web y un libro de dominio público.
- **Archivos `.csv`**: datos abiertos de clima y de biología.

El programa está dividido en módulos y funciones, valida todas las entradas del usuario, no se cierra ante errores (archivos inexistentes, rutas inválidas, celdas vacías, archivos vacíos) y guarda cada gráfico como imagen PNG en la carpeta `/outputs`.

Solo usa la biblioteca estándar de Python (`os`, `csv`) y **matplotlib** para los gráficos.

---

## Cómo ejecutarlo

```bash
pip install matplotlib
python main.py
```

Requiere Python 3.8 o superior. Si matplotlib no está instalado, el programa sigue funcionando en consola y solo avisa que no puede dibujar los gráficos.

---

## Estructura del proyecto

```
proyecto_analisis_datos/
├── main.py                    # Menú principal
├── requirements.txt
├── modulos/
│   ├── config.py              # Rutas, constantes, palabras vacías, valores nulos
│   ├── utilidades.py          # Entrada validada, top_n, formato de números
│   ├── archivos.py            # Explorar carpeta, elegir y leer archivos
│   ├── analisis_texto.py      # Cálculos del submenú .txt
│   ├── menu_texto.py          # Submenú 1 (interacción con el usuario)
│   ├── analisis_csv.py        # Cálculos del submenú .csv
│   ├── menu_csv.py            # Submenú 2 (interacción con el usuario)
│   └── graficos.py            # Los 5 tipos de gráfico (barh, hist, plot, pie, scatter)
├── data/                      # Archivos reales usados en las pruebas
├── outputs/                   # Gráficos generados por el programa (10 PNG)
└── diagramas/                 # Diagramas de flujo (PNG + PDF + fuentes Mermaid)
```

Se separó la **lógica** (módulos `analisis_*`, que solo calculan y devuelven resultados) de la **interacción** (módulos `menu_*`, que muestran y piden datos). Así cada cálculo se puede probar por separado.

---

## Funcionalidades

```mermaid
flowchart TD
    A([Inicio]) --> M[/Menú principal/]
    M --> O1[[1. Explorar directorio]]
    M --> O2[[2. Procesar textos .txt]]
    M --> O3[[3. Analizar dataset .csv]]
    M --> O4([4. Salir])
    O2 --> T1[Resumen estadístico]
    O2 --> T2[Extracción de patrones]
    O2 --> T3[Gráfico 1: barh]
    O2 --> T4[Gráfico 2: hist]
    O3 --> C1[Vista previa]
    O3 --> C2[Estadísticas descriptivas]
    O3 --> C3[Gráfico 3: plot]
    O3 --> C4[Gráfico 4: pie]
    O3 --> C5[Gráfico 5: scatter]
```

| Opción | Qué hace |
|---|---|
| **Explorar directorio** | Lista los `.txt` y `.csv` de la ruta que escriba el usuario (tipo, tamaño y nombre). Esa carpeta queda seleccionada para los submenús. |
| **Resumen estadístico** | Líneas (y cuántas vacías), palabras, caracteres con y sin espacios y top 5 de palabras sin conectores. |
| **Extracción de patrones** | Detecta si el archivo es un log y cuenta niveles de severidad (`ERROR`, `NOTICE`…), códigos HTTP (`404`, `500`…), registros por fecha y palabras clave de error. Permite buscar cualquier texto o fecha. |
| **Gráfico 1 – `barh`** | Las 10 palabras más frecuentes. |
| **Gráfico 2 – `hist`** | Líneas agrupadas por longitud: 0-50, 51-100, 101-150… caracteres. |
| **Vista previa** | Columnas con su tipo detectado, primeras 10 filas y últimas 5. |
| **Estadísticas descriptivas** | Limpia nulos (`""`, `NA`, `null`, `nan`…) y calcula registros válidos, promedio, mediana, máximo y mínimo. |
| **Gráfico 3 – `plot`** | Evolución de una columna numérica según otra (por ejemplo, fecha). Opcional: promedio móvil para ver la tendencia. |
| **Gráfico 4 – `pie`** | Porcentaje de participación de cada categoría (las pequeñas se agrupan en «Otros» si hay más de 7). |
| **Gráfico 5 – `scatter`** | Relación entre dos columnas numéricas, con el coeficiente de correlación de Pearson *r*. Opcional: colorear los puntos por una columna categórica. |

**Detalles de robustez:** el programa detecta la codificación del archivo (UTF-8 o Latin-1), el separador del CSV (`,` `;` tabulador o `|`), acepta números con coma decimal (`3,5` o `1.200,5`), omite la licencia en inglés de los libros del Proyecto Gutenberg y termina limpiamente con `Ctrl+C`.

---

## Datos elegidos

| Archivo en `/data` | Qué representa | De dónde salió |
|---|---|---|
| `don_quijote_cervantes.txt` | Texto completo de *Don Quijote de la Mancha* (Miguel de Cervantes), 37.862 líneas, codificación ISO-8859-1. | Proyecto Gutenberg, eBook #2000 (dominio público), copia del repositorio GITenberg en GitHub. |
| `apache_access_log.txt` | 10.000 peticiones reales a un servidor web Apache entre el 17 y el 20 de mayo de 2015 (IP, fecha, petición, código HTTP, navegador). | Repositorio de ejemplos de Elastic (`elastic/examples`, carpeta *Common Data Formats/apache_logs*). |
| `apache_error_log.txt` | 2.000 líneas de la bitácora de errores de un servidor Apache en Linux (4 y 5 de diciembre de 2005). | Colección Loghub (`logpai/loghub`), publicada para investigación en detección de anomalías. |
| `clima_seattle_2012_2015.csv` | Clima diario de Seattle (EE. UU.) de 2012 a 2015: precipitación (mm), temperatura máxima y mínima (°C), viento y tipo de día. 1.461 registros. | Datos de NOAA (National Climatic Data Center), distribuidos en el repositorio `vega/vega-datasets`. |
| `pinguinos_palmer.csv` | Medidas de 344 pingüinos de tres especies en la Antártida: largo y profundidad del pico, largo de la aleta, masa corporal, sexo, isla y año. Tiene celdas `NA` reales. | Dra. Kristen Gorman y Palmer Station LTER, publicado como `palmerpenguins` (licencia CC0). |

Notas sobre los datos:

- La columna `weather` del clima de Seattle **no es una medición directa**: según la documentación de *vega-datasets*, se sintetizó a partir de varios campos del registro original de NOAA. Por eso las conclusiones con esa columna se toman como aproximadas.
- El dataset de pingüinos se eligió a propósito porque trae **datos faltantes** (`NA`): sirve para comprobar que el programa limpia los nulos antes de calcular.
- El libro está en Latin-1 y con saltos de línea de Windows; el log de accesos está en UTF-8. Esto permitió probar la detección automática de codificación.

---

## Conclusiones

### 1. En Seattle la lluvia no es constante: tiene temporada

![Participación por tipo de clima](outputs/g4_pie_clima_seattle_2012_2015_weather.png)
![Precipitación diaria con promedio móvil](outputs/g3_plot_clima_seattle_2012_2015_precipitation_por_date.png)

El gráfico de pastel muestra que entre 2012 y 2015 hubo prácticamente la misma cantidad de días de lluvia (641, **43,9 %**) que de sol (640, **43,8 %**). Sin embargo, el gráfico de líneas con promedio móvil de 30 días muestra que la lluvia se concentra en otoño e invierno: el promedio sube a entre 6 y 11 mm por día alrededor de noviembre a marzo y cae casi a 0 mm en julio y agosto, todos los años. Las estadísticas descriptivas lo confirman: la **mediana de la precipitación es 0 mm**, es decir, más de la mitad de los días no llovió nada, aunque el promedio es 3,03 mm.

**Conclusión:** la fama de "ciudad lluviosa" viene de inviernos muy húmedos, no de que llueva todo el año. El promedio por sí solo engaña; hay que mirar la mediana y la evolución en el tiempo.

### 2. En los pingüinos, aleta larga = pingüino pesado, pero la especie explica gran parte de la relación

![Masa corporal vs. largo de aleta por especie](outputs/g5_scatter_pinguinos_palmer_body_mass_g_vs_flipper_length_mm.png)

El gráfico de dispersión entre largo de aleta y masa corporal da **r = 0,87**, una correlación fuerte y positiva (342 pares válidos, después de eliminar 2 filas con `NA`). Al colorear por especie aparecen dos grupos separados: los **Gentoo** forman una nube aparte, con aletas de unos 203 a 231 mm y masas de hasta 6.300 g, mientras que **Adelie** y **Chinstrap** se mezclan entre sí con aletas más cortas y masas menores. Dentro de cada especie la tendencia también es positiva, pero más débil a la vista.

El pastel por especie (Adelie 44,2 %, Gentoo 36,0 %, Chinstrap 19,8 %) y las estadísticas de `body_mass_g` (promedio 4.201,75 g mayor que la mediana 4.050 g) muestran el mismo efecto: el grupo de Gentoo, más pesado, "jala" el promedio hacia arriba.

**Conclusión:** una correlación fuerte en el conjunto completo puede deberse en parte a que se mezclan grupos distintos. Antes de concluir que "una variable causa la otra" conviene separar por categorías.

### 3. Don Quijote es una novela de diálogo entre dos personajes, y la longitud de las líneas no dice nada del autor

![Palabras más frecuentes en Don Quijote](outputs/g1_barh_palabras_don_quijote_cervantes.png)
![Longitud de las líneas en Don Quijote](outputs/g2_hist_longitudes_don_quijote_cervantes.png)

Sin contar conectores, las palabras más repetidas son **don** (2.648), **quijote** (2.176) y **sancho** (2.148): los dos protagonistas dominan el texto casi por igual. Les siguen **dijo** (1.808) y **respondió** (1.063), verbos de diálogo, lo que muestra que gran parte del libro son conversaciones. También aparecen **señor** y **merced** (de la fórmula de cortesía "vuestra merced", que la búsqueda de patrones encontró en 552 líneas) y **caballero**, el tema central de la obra.

El histograma, en cambio, muestra que el **85,3 %** de las líneas no vacías tiene entre 51 y 100 caracteres y ninguna pasa de 100. Eso no es estilo de Cervantes: el archivo del Proyecto Gutenberg corta las líneas a un ancho fijo.

**Conclusión:** la frecuencia de palabras sí revela el contenido del libro, pero la longitud de las líneas refleja el formato del archivo, no la escritura. Hay que saber cómo se creó un archivo antes de interpretar sus métricas.

---

## Otros hallazgos

- **Temperatura en Seattle** (`g3_plot_..._temp_max_por_date.png`, `g5_scatter_..._temp_max_vs_temp_min.png`): el ciclo de estaciones se repite cada año, con máximas promedio de unos 5–8 °C en invierno y 26–29 °C en verano. El pico de verano del promedio móvil fue un poco más alto cada año (cerca de 26 °C en 2012 y de 29 °C en 2015), pero cuatro años son muy pocos para hablar de una tendencia climática. La temperatura máxima y la mínima del mismo día tienen una correlación fuerte (**r = 0,88**).
- **Lluvia y viento** (`g5_scatter_..._precipitation_vs_wind.png`): la relación es débil (**r = 0,33**). Los días ventosos tienden a ser un poco más lluviosos, pero hay muchos días con viento y sin lluvia.
- **Log de accesos**: el 91,3 % de las peticiones respondió `200` (éxito). Hubo 217 errores de cliente (4xx), de los cuales **213 son `404`** (página no encontrada), y solo 3 errores del servidor (`500`). El 17 de mayo tiene muchos menos registros (1.632) que el 18 y el 19 (cerca de 2.900 cada uno) porque el archivo empieza ese día a las 10:05, y el 20 tiene 2.579 porque termina a las 21:05: antes de comparar días hay que revisar que estén completos. El histograma (`g2_hist_longitudes_apache_access_log.png`) muestra que el 77 % de las líneas mide entre 151 y 300 caracteres.
- **Log de errores**: el **29,8 %** de las líneas son de nivel `ERROR`. La búsqueda de patrones encontró el mensaje *"workerEnv in error state"* en 539 líneas, es decir, un solo problema del módulo `mod_jk` explica alrededor del 90 % de los errores.

---

## Diagramas de flujo

La carpeta [`diagramas/`](diagramas/) contiene:

- `00_leyenda_simbolos.png`: significado de cada símbolo.
- `01_main_menu_principal.png`: diagrama del menú principal.
- `02` a `33`: un diagrama independiente por cada función (submenús, cada opción y las funciones de apoyo como `top_n`, `convertir_a_numero`, `correlacion_pearson` o `promedio_movil`).
- `diagramas_de_flujo.pdf`: todos los diagramas en un solo documento, con índice.
- `fuentes_mermaid/`: el código fuente de cada diagrama. Se puede editar y volver a dibujar en [mermaid.live](https://mermaid.live).

---

## Fuentes de los datos

- Cervantes, M. *Don Quijote*. Project Gutenberg eBook #2000. Copia en GitHub: `GITenberg/Don-Quijote_2000`.
- Elastic. *Common Data Formats – apache_logs*. GitHub: `elastic/examples`.
- Zhu, J., He, S., He, P., Liu, J. y Lyu, M. R. (2023). *Loghub: A Large Collection of System Log Datasets for AI-driven Log Analytics*. ISSRE. GitHub: `logpai/loghub`.
- NOAA National Climatic Data Center, vía `vega/vega-datasets` (archivo `seattle-weather.csv`).
- Horst, A. M., Hill, A. P. y Gorman, K. B. (2020). *palmerpenguins: Palmer Archipelago (Antarctica) penguin data*. Datos de Palmer Station Antarctica LTER, licencia CC0.
